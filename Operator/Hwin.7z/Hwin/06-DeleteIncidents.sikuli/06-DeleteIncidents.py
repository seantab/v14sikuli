# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

DynURL = "http://kbush-helmond-dynac.transdyn.com:8080"
DynTitle = "DYNAC - dynac64"    #DynaApp Window Title

                    #-------  Global Hotkey --------------
#setup global hot key to terminate execution for each script
def terminate(event):
    term = (False)
    exit()
# When the user pressed Ctrl+Alt+F1, terminate program
Env.addHotkey(Key.SPACE, KeyModifier.CTRL+KeyModifier.ALT, terminate)
                    #------- End Global Hotkey --------------

# ---------------------------  End of Initialization & Variables --------------

#------------- Clean up Incident Module -------------------
switchApp(DynTitle)  #use this if Sikuli run locally otherwise ignore if run in VSphere
wait(sw)
rightClick(Pattern("WinDynacMenu.PNG").targetOffset(28,24))     #close all other windows
click(Pattern("WinDynacMenu.PNG").targetOffset(62,60))

wait(sw)    # wait to Reset Screen
click(Pattern("homeButton-1.png").targetOffset(-218,236))    # Click on IRM triangle ICON on the left
wait(lw)
i=0
while ((exists(Pattern("IRMExists3.png").similar(0.80).targetOffset(70,9)) or exists("IRMExists1.png"))and i<=8):
    i=i+1
    doubleClick(Pattern("IRMActiveIncidents.png").similar(0.90).targetOffset(78,21))        #open the incident
    wait(lw)
    if exists(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.80).targetOffset(-1,1)):     #Maximize Incident Confirmation Window
        wait(sw)
        click(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.80).targetOffset(-1,1))
    else:
        exit
    wait(lw)
    if exists("TakeControlButton.png"):
        click("TakeControlButton.png")    #Take Control of Incident so we can delete it
    else:
        exit

    wait(sw) 
    click("TerminateIncidentBTN.png")    #terminate Incident button
    wait(sw)
    click(Pattern("TerminateIncidentYESBTN.png").targetOffset(90,69))    #confirm Deletion of incident
    wait(sw)
    click(Pattern("DynMessageBTN.png").targetOffset(276,69))    #click Dynac ok button to get to main screen
    wait(sw)
else:
    print ("Total Incidents deleted = ",i)
    exit
wait(sw)
rightClick(Pattern("WinDynacMenu.PNG").targetOffset(28,24))     #close all other windows
click(Pattern("WinDynacMenu.PNG").targetOffset(62,60))
wait(lw)
#------------- End of Clean up Incident Module -------------------   