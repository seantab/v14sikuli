# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

                    #-------  Global Hotkey --------------
#setup global hot key to terminate execution for each script
def terminate(event):
    term = (False)
    exit()
# When the user pressed Ctrl+Alt+F1, terminate program
Env.addHotkey(Key.SPACE, KeyModifier.CTRL+KeyModifier.ALT, terminate)
                    #------- End Global Hotkey --------------

# ---------------------------  End of Initialization & Variables --------------

#---------------------- Investigate Walk for Incident #5 ------------------------------
hover(Pattern("homeButton-1.png").targetOffset(-57,2))    #Hover and click  home button to rest the screen
click(Pattern("homeButton-1.png").targetOffset(-57,2))
wait(sw)    # wait to Reset Screen        

i=0    #set numblers of Drag iterations
while(exists(Pattern("gray1.png").exact()) and i<=3 and term):    #Gray tile detection.  Wait anytime you see this until disappears
    i= i+1
    wait(sw*i)
else:
    exit

hover(Pattern("homeButton.png").targetOffset(69,-1))     
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)

dragDrop("Inc5drag1.png",Pattern("homeButton.png").targetOffset(520,390))

hover("Inc5drag1.png")    # zoom IN this area

dragDrop(Pattern("Inc5drag2.png").targetOffset(90,-10),Pattern("homeButton.png").targetOffset(520,390))
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
dragDrop(Pattern("Inc5Loc1.png").targetOffset(51,-47),Pattern("homeButton.png").targetOffset(520,390))

#-------------- End of Investigate walk 5 ------------------------------------------

#-------------------------------- Create Incident #5-------------------------------

wait(sw)
i=0
while(not exists(Pattern("Inc5Loc1.png").targetOffset(71,-114)) and i<=0):
    i=i+1
    wait(sw*i)
else:
    exit

click(Pattern("Inc5Loc1.png").targetOffset(71,-114))
wait(sw)
rightClick(Pattern("Inc5Loc1.png").targetOffset(71,-114))
wait(sw)
click(Pattern("GISMapMenu.png").targetOffset(36,-317))
wait(lw)

if exists(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.75).targetOffset(-1,1)):        #Maximize Incident Confirmation Window
    click(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.80).targetOffset(-1,1))
else:
    exit

wait(sw)
wait(Pattern("IncidentWinView.png").similar(0.30), 10)

i=0
while (not exists(Pattern("createMenu.png").similar(0.50).targetOffset(-69,0)) and i<3):
    i=i+1
    dragDrop(Pattern("IncidentWinSlider.png").targetOffset(1,20),Pattern("IncidentWinSlider.png").targetOffset(202,17))
else:
    exit

dragDrop(Pattern("Incident1Cordinates.png").targetOffset(9,23),Pattern("Incident1Cordinates.png").targetOffset(-101,24))    #clear Roadway field
type("Incident1Cordinates.png","A7L")
dragDrop(Pattern("Incident1Cordinates.png").targetOffset(55,22),Pattern("Incident1Cordinates.png").targetOffset(163,21))    #clear Linear Ref field
type("Incident1Cordinates.png","2.05")
wait(sw)
click(Pattern("createMenu.png").similar(0.50).targetOffset(-69,0))
print ("Incident #5 Created")
wait(lw)

i=0
while (exists(Pattern("closeIncidentWin.png").targetOffset(-28,3)) and i<3):
    click(Pattern("closeIncidentWin.png").targetOffset(-28,3))
    i=1+1
    wait(sw*i)
else:
    exit
  
wait(lw)
hover(Pattern("homeButton-1.png").targetOffset(-57,2))    #Hover and click  home button to rest the screen
click(Pattern("homeButton-1.png").targetOffset(-57,2))
wait(sw)    # wait to Reset Screen  

#------------- End of Create Incident #5-------------------