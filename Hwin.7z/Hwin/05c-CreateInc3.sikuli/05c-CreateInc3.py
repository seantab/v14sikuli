# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

# ---------------------------  End of Initialization & Variables --------------

#---------------------- Investigate Walk for Incident #3 ------------------------------
hover(Pattern("homeButton-1.png").targetOffset(-57,2))    #Hover and click  home button to rest the screen
click(Pattern("homeButton-1.png").targetOffset(-57,2))
wait(sw)    # --Reset Screen        

i=0    #set numblers of Drag iterations
while(exists(Pattern("gray1.png").exact()) and i<=3 and term):    #Gray tile detection.  Wait anytime you see this until disappears
    i= i+1
    wait(sw*i)
else:
    exit

hover(Pattern("homeButton.png").targetOffset(69,-1))     
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)

dragDrop("Inc3drag1a.png",Pattern("homeButton.png").targetOffset(520,390))
while(exists(Pattern("gray1.png").exact()) and i<=3 and term):    #Gray tile detection.  Wait anytime you see this until disappears
    i= i+1
    wait(sw*i)
else:
    exit

dragDrop(Pattern("Inc3drag1.png").targetOffset(0,1),Pattern("homeButton.png").targetOffset(520,390))

wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)

#-------------- End of Investigate walk 3 ------------------------------------------

#-------------------------------- Create Incident #3-------------------------------

wait(sw)
i=0
while(not exists(Pattern("Inc3Loc1.png").targetOffset(37,-60)) and i<=0):
    i=i+1
    wait(sw*i)
else:
    exit

click(Pattern("Inc3Loc1.png").targetOffset(37,-60))
wait(sw)
rightClick(Pattern("Inc3Loc1.png").targetOffset(37,-60))
wait(sw)
click(Pattern("GISMapMenu.png").targetOffset(36,-317))
wait(lw)

if exists(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.75).targetOffset(-1,1)):        #Maximize Incident Confirmation Window
    click(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.80).targetOffset(-1,1))
else:
    exit

wait(sw)
wait(Pattern("IncidentWinView-1.png").similar(0.60), 10)

i=0
while (not exists(Pattern("createMenu-1.png").similar(0.50).targetOffset(-69,0)) and i<3):
    i=i+1
    dragDrop(Pattern("IncidentWinSlider-1.png").targetOffset(1,20),Pattern("IncidentWinSlider-1.png").targetOffset(202,17))
else:
    exit

doubleClick(Pattern("Incident1Cordinates-1.png").targetOffset(-42,28))
wait(sw)
type("A28L")
doubleClick(Pattern("Incident1Cordinates-1.png").targetOffset(42,74))
wait(sw)
type("24.18")
wait(sw)

click(Pattern("createMenu-1.png").similar(0.60).targetOffset(-69,0))

print ("Incident #3 Created")
wait(lw)
i=0
while (not exists(Pattern("TerminateIncident.png").similar(0.80)) and i<=3):
    i+=1
    wait(sw*i)
else:
    click(Pattern("TerminateIncident.png").similar(0.80))
    wait(sw)
    click("YesTerminateBTN.png")
    wait(sw)
    click("OKTerminateBTN.png")
    wait(sw)
    exit

"""   #~^~^~^~^~^~ BLOCKED BELOW CODE ~^~^~^~^~^~
i=0
while (exists(Pattern("closeIncidentWin-1.png").targetOffset(-28,3)) and i<=3):
    click(Pattern("closeIncidentWin-1.png").targetOffset(-28,3))
    i=1+1
    wait(sw*i)
else:
    exit

"""""   #~^~^~^~^~^~ END OF BLOCKED CODE ABOVE ~^~^~^~^~^~

wait(sw)

hover(Pattern("homeButton-1.png").targetOffset(-57,2))    #Hover and click  home button to rest the screen
click(Pattern("homeButton-1.png").targetOffset(-57,2))

#------------- End of Create Incident #3-------------------