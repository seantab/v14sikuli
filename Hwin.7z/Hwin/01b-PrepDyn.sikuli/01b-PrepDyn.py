# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay
DynTitle = "DYNAC"    #DynaApp Window Title

# ---------------------------  End of Initialization & Variables --------------

switchApp(DynTitle)  #use this if Sikuli run locally otherwise ignore if run in VSphere

#    Maximize Dynac Window
wait(sw)        
if exists("DLogoLinux-2.png"):   #for Linux
    hover ("DLogoLinux-2.png")
    click ("DLogoLinux-2.png")
    check = 0
    while(not exists(Pattern("DynWinMaxed-1.png").similar(0.80).targetOffset(-54,-27)) and check <1 and term):
        check=check+1
        hover (Pattern("DLogoLinux-2.png").targetOffset(47,30))    #hover to Maximize
        click (Pattern("DLogoLinux-2.png").targetOffset(47,30))    #Maximize
        exit
    else:
        click (Pattern("DLogoLinux-2.png").targetOffset(347,1))
        exit
else:
    hover("DLogoWin-1.png")        #for Windows
    click("DLogoWin-1.png")
    hover(Pattern("DLogoWin-1.png").targetOffset(37,117))        #hover to Maximize
    click(Pattern("DLogoWin-1.png").targetOffset(37,117))        #Maximize 
    click(Pattern("DLogoWin-1.png").targetOffset(312,1))        #click away to get rid of dropdown menu 

wait(sw)
if exists(Pattern("ReminderDialog-1.png").targetOffset(85,2)):
    click (Pattern("ReminderDialog-1.png").targetOffset(85,2))
else:
    exit
    
if exists(Pattern("ReminderDialog2-1.png").targetOffset(83,0)):
    click(Pattern("ReminderDialog2-1.png").targetOffset(83,0)) 
else:
    exit 

if exists(Pattern("ReminderDialog-3.png").similar(0.80)):
    click(Pattern("ReminderDialog-3.png").similar(0.80).targetOffset(-69,-16)) 
else:
    exit         
wait(sw)
# -------------------- - END PREP DYNAC----------------------------