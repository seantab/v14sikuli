




        
    dragDrop(Pattern("image1-2.png").targetOffset(191,137),Pattern("image1-2.png").targetOffset(158,635) )    #vertical move North to South
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    dragDrop(Pattern("image1-2.png").targetOffset(1181,131),Pattern("image1-2.png").targetOffset(101,175) )    #Horizontal move right to left
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    click(Pattern("image1-2.png").targetOffset(186,175))
    wheel(Pattern("image1-2.png").targetOffset(186,175), WHEEL_UP,2)    # zoom in this area
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    dragDrop(Pattern("image1-2.png").targetOffset(132,125),Pattern("image1-2.png").targetOffset(1083,533) )    #Diagnol move NW to SW
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    dragDrop(Pattern("image1-2.png").targetOffset(292,653),Pattern("image1-2.png").targetOffset(1006,244) )    #Diagnol SW to NE
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    wheel(Pattern("image1-2.png").targetOffset(186,175), WHEEL_UP,-3)    # Reset zoom back
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    wait(sw)
    wheel(Pattern("image1-2.png").targetOffset(676,235), WHEEL_DOWN,3)    # zoom out in this area
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    wait(lw)
    dragDrop(Pattern("image1-2.png").targetOffset(372,121),Pattern("image1-2.png").targetOffset(768,497) )    #vertical move North to South
    w=0    #set numblers of wait for gray iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    wheel(Pattern("image1-2.png").targetOffset(676,235), WHEEL_DOWN,-3)   # Reset Zoom
    w=0    #set numblers of Drag iterations
    while(exists(Pattern("gray1-1.png").exact()) and w<=3 and term):
        w+=1
        wait(sw*w)
    else:
        exit

    wait(lw)
    
else:
    print("end of dragging")

hover(Pattern("homeButton-3.png").targetOffset(-57,2))    #Hover and click  ome button to rest the screen
click(Pattern("homeButton-3.png").targetOffset(-57,2))
wait(sw)

#---------------- End of Walk
