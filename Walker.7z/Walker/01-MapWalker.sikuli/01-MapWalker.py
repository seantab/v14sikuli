# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= .5    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= .5    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 0.1     #Short Wait
lw= 3      #Long Wait
xlt = 5    # Extra Long Wait Time
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

# ---------------------------  End of Initialization & Variables --------------

#---------------------- Map Walker  ------------------------------
def Gray ():
    w=0    #set numbers of wait for gray iterations
    while(exists(Pattern("gray1.png").exact()) and w<=2):
        w+=1
        wait(sw+w)
    else:
        exit
Gray = Gray()


i=0    #set numblers of Drag iterations
drags=0    #set number of drags and drop for operator

hover(Pattern("homeButton-2.png").targetOffset(-57,2))    #Hover and click  home button to rest the screen
click(Pattern("homeButton-2.png").targetOffset(-57,2))
wait(1)
Gray
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(1)
Gray
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN to 200 M
Gray
# ---------------- Start Walking -------------------
water =(Pattern("Water.png").similar(0.90))
grass = (Pattern("Grass.png").exact())

drags = 0
while (not exists(grass) and drags <=5):
    drags=drags+1
    dragDrop(Pattern("image1-3.png").targetOffset(159,275),Pattern("image1-3.png").targetOffset(1113,275) )    #Horizontal move to left
    Gray
    print "Moving to the left of Screen"
else:
    exit
 
drags = 0
while (drags <=3):
    drags=drags+1
    dragDrop(Pattern("image1-3.png").targetOffset(718,127),Pattern("image1-3.png").targetOffset(714,557) )    #Go up the screen
    Gray
    print "Moving up the screen"
else:
    exit    
drags = 0
while (drags <=3):
    drags=drags+1
    dragDrop(Pattern("image1-3.png").targetOffset(1064,398),Pattern("image1-3.png").targetOffset(301,398) )    #Move to right
    Gray
    print "moving to right"
else:
    exit    