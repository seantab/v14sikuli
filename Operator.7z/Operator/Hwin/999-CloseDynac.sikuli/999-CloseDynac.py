# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

DynURL = "http://kbush-helmond-dynac.transdyn.com:8080"
DynTitle = "DYNAC - dynac64"    #DynaApp Window Title

                    #-------  Global Hotkey --------------
#setup global hot key to terminate execution for each script
def terminate(event):
    term = (False)
    exit()
# When the user pressed Ctrl+Alt+F1, terminate program
Env.addHotkey(Key.SPACE, KeyModifier.CTRL+KeyModifier.ALT, terminate)
                    #------- End Global Hotkey --------------

# ---------------------------  End of Initialization & Variables --------------
#switchApp(DynTitle)  #use this if Sikuli run locally otherwise ignore if run in VSphere
wait(sw)

if(exists(Pattern("WinDynacMenu.png").similar(0.80).targetOffset(-70,0))):
    dragDrop(Pattern("WinDynacMenu.png").similar(0.80).targetOffset(-70,0),Pattern("WinDynacMenu.png").targetOffset(-43,77))    
else:
    dragDrop(Pattern("DynacMenu.png").targetOffset(-194,0),Pattern("DynacMenu.png").targetOffset(-157,89))
    exit

wait(sw)
click(Pattern("SessionExitBtn.png").similar(0.64))
wait(sw)