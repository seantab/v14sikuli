# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

DynURL = "http://kbush-helmond-dynac.transdyn.com:8080"
DynTitle = "DYNAC - dynac64"    #DynaApp Window Title
UID = "testuser1"
PWD = "transdyn"

                    #-------  Global Hotkey --------------
#setup global hot key to terminate execution for each script
def terminate(event):
    term = (False)
    exit()
# When the user pressed Ctrl+Alt+F1, terminate program
Env.addHotkey(Key.SPACE, KeyModifier.CTRL+KeyModifier.ALT, terminate)
                    #------- End Global Hotkey --------------

# ---------------------------  End of Initialization & Variables --------------

App.close("firefox")
wait(sw)
openApp (r"javaws -uninstall")    #Uninstall Cache
wait(sw)
openApp (r"javaws -clearcache")    #clear Cache
wait(sw)
openApp (r"javaws C:\Sikuli\Scripts\Dynapp.jnlp")    #Launch DynApp through JNLP file

i=0
while(exists("DynAppLoading.png") and i<=5):        #Wait for DynacApp to load
    i+=1
    wait(sw*i)
else:
    exit

i=0
while (not exists("DynAppStart.png") and i<=3):
    i+=1
    wait(sw*i)
else:
    click(Pattern("DynAppStart.png").targetOffset(195,172))     #Click Run on DynApp Java program 

switchApp("DYNAC Login")  #Bring up Dynac Java Login screen

i=0
while(not exists("LoginDynApp.png") and i<=3):
    i+=1
    wait(lw*i)
else:
   type(Pattern("LoginDynApp.png").targetOffset(46,-49),UID) 
   wait(sw)
   type(Pattern("LoginDynApp.png").targetOffset(47,-16),PWD)
   wait(sw)
   click(Pattern("LoginDynApp.png").targetOffset(50,43))
   exit()

i=0

wait(sw)
App.close("firefox")
wait(sw)
switchApp(DynTitle)  #use this if Sikuli run locally otherwise ignore if run in VSphere
wait(xlt)    #wait for DynApp to load completely usually takes 10 secs