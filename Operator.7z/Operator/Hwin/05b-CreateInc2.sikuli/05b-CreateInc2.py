# ---------------------------  Initialization & Variables --------------
i= 0    # to reset all the iterations that used "i" unless explecitly set
mmt= 1.0    #mouse move time  Put 0.1 -10 for speed in secs.
dbmd= 1.0    #Delay before Mouse Down   Put 0.1 -10 for speed in secs.
sw = 2        #Short Wait
lw= 5      #Long Wait
xlt = 10    # Extra Long Wait Time
term =(True)
Settings.MoveMouseDelay = mmt    #fast mouse
DelayBeforeMouseDown = dbmd    #mouse click delay

DynURL = "http://kbush-helmond-dynac.transdyn.com:8080"
DynTitle = "DYNAC - dynac64"    #DynaApp Window Title

                    #-------  Global Hotkey --------------
#setup global hot key to terminate execution for each script
def terminate(event):
    term = (False)
    exit()
# When the user pressed Ctrl+Alt+F1, terminate program
Env.addHotkey(Key.SPACE, KeyModifier.CTRL+KeyModifier.ALT, terminate)
                    #------- End Global Hotkey --------------

# ---------------------------  End of Initialization & Variables --------------

#---------------------- Investigate Walk for Incident #2 ------------------------------
wait(sw)    # --Reset Screen        

hover(Pattern("homeButton.png").targetOffset(-57,2))    #Hover and click  home button
click(Pattern("homeButton.png").targetOffset(-57,2))

i=0    #set numblers of Drag iterations
while(exists(Pattern("gray1.png").exact()) and i<=3 and term):    #Gray tile detection.  Wait anytime you see this until disappears
    i= i+1
    wait(sw*i)
else:
    exit

hover(Pattern("homeButton.png").targetOffset(69,-1))     
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(69,-1))    # zoom out this area
wait(sw)

dragDrop(Pattern("Inc2drag1.png").targetOffset(96,-241),Pattern("homeButton.png").targetOffset(520,390))    #drag to Center of Screen

wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)
click(Pattern("homeButton.png").targetOffset(45,-1))    # zoom IN this area
wait(sw)


#-------------- End of Investigate walk 2 ------------------------------------------

#-------------------------------- Create Incident #2-------------------------------

wait(sw)
i=0
while(not exists(Pattern("Inc2Loc2.png").targetOffset(-23,33)) and i<=0):
    i=i+1
    wait(sw*i)
else:
    exit

click(Pattern("Inc2Loc2.png").targetOffset(-23,33))
wait(sw)
rightClick(Pattern("Inc2Loc2.png").targetOffset(-23,33))
wait(sw)
click(Pattern("GISMapMenu.png").targetOffset(36,-317))
wait(lw)

if exists(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.75).targetOffset(-1,1)):        #Maximize Incident Confirmation Window
    click(Pattern("IncidentConfirmationMaxMinbtn.png").similar(0.80).targetOffset(-1,1))
else:
    exit

wait(sw)
wait(Pattern("IncidentWinView.png").similar(0.30), 10)

i=0
while (not exists(Pattern("createMenu.png").similar(0.50).targetOffset(-69,0)) and i<3):
    i=i+1
    dragDrop(Pattern("IncidentWinSlider.png").targetOffset(1,20),Pattern("IncidentWinSlider.png").targetOffset(202,17))
else:
    exit

dragDrop(Pattern("Incident1Cordinates.png").targetOffset(9,23),Pattern("Incident1Cordinates.png").targetOffset(-101,24))    #clear Roadway field
type("Incident1Cordinates.png","A4R")
dragDrop(Pattern("Incident1Cordinates.png").targetOffset(55,22),Pattern("Incident1Cordinates.png").targetOffset(163,21))    #clear Linear Ref field
type("Incident1Cordinates.png","44.44")
wait(sw)
click(Pattern("createMenu.png").similar(0.50).targetOffset(-69,0))
print ("Incident #2 Created")
wait(lw)

i=0
while (not exists(Pattern("TerminateIncident-1.png").similar(0.80)) and i<=3):
    i+=1
    wait(sw*i)
else:
    click(Pattern("TerminateIncident-1.png").similar(0.80))
    wait(sw)
    click("YesTerminateBTN-1.png")
    wait(sw)
    click("OKTerminateBTN-1.png")
    wait(sw)
    exit

"""   #~^~^~^~^~^~ BLOCKED BELOW CODE ~^~^~^~^~^~
i=0
while (exists(Pattern("closeIncidentWin-2.png").targetOffset(-28,3)) and i<=3):
    click(Pattern("closeIncidentWin-2.png").targetOffset(-28,3))
    i=1+1
    wait(sw*i)
else:
    exit

"""""   #~^~^~^~^~^~ END OF BLOCKED CODE ABOVE ~^~^~^~^~^~

wait(sw)


hover(Pattern("homeButton-2.png").targetOffset(-57,2))    #Hover and click  home button to rest the screen
click(Pattern("homeButton-2.png").targetOffset(-57,2))
wait(sw)
#------------- End of Create Incident #2-------------------